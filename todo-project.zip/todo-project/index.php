<?php
require_once 'config/db.php';

// Fetch all todos
try {
    $stmt = $pdo->query("SELECT * FROM todos ORDER BY created_at DESC");
    $todos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching todos: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Todo App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --success-color: #1cc88a;
            --danger-color: #e74a3b;
            --light-bg: #f8f9fc;
        }
        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            margin-bottom: 20px;
        }
        .card-header {
            background-color: white;
            border-bottom: 1px solid #e3e6f0;
            font-weight: 600;
            padding: 1rem 1.35rem;
            border-radius: 10px 10px 0 0 !important;
        }
        .list-group-item {
            border-left: none;
            border-right: none;
            padding: 1.25rem 1.5rem;
            transition: all 0.2s;
        }
        .list-group-item:first-child {
            border-top: none;
        }
        .list-group-item:hover {
            background-color: #f8f9fa;
            transform: translateX(5px);
        }
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-success {
            background-color: var(--success-color);
            border-color: var(--success-color);
        }
        .btn-danger {
            background-color: var(--danger-color);
            border-color: var(--danger-color);
        }
        .todo-completed {
            background-color: rgba(28, 200, 138, 0.1);
        }
        .todo-actions .btn {
            margin-right: 5px;
        }
        .todo-date {
            font-size: 0.8rem;
            color: #858796;
        }
        .empty-state {
            text-align: center;
            padding: 2rem;
            color: #b7b9cc;
        }
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            display: block;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h3 text-gray-800"><i class="bi bi-check2-circle"></i> My Todo List</h1>
                    <span class="badge bg-primary rounded-pill"><?= count($todos) ?> items</span>
                </div>
                
                <!-- Add Todo Form -->
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="bi bi-plus-circle"></i> Add New Task</h5>
                    </div>
                    <div class="card-body">
                        <form action="add.php" method="POST">
                            <div class="mb-3">
                                <label for="title" class="form-label">Task Title *</label>
                                <input type="text" class="form-control" id="title" name="title" placeholder="What needs to be done?" required>
                            </div>
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea class="form-control" id="description" name="description" rows="2" placeholder="Additional details..."></textarea>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-plus-lg"></i> Add Task
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Todo List -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="bi bi-list-task"></i> My Tasks</h5>
                        <div class="btn-group">
                            <button class="btn btn-sm btn-outline-secondary">All</button>
                            <button class="btn btn-sm btn-outline-secondary">Active</button>
                            <button class="btn btn-sm btn-outline-secondary">Completed</button>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <?php if (empty($todos)): ?>
                            <div class="empty-state">
                                <i class="bi bi-emoji-frown"></i>
                                <h5>No tasks found</h5>
                                <p>Add your first task using the form above</p>
                            </div>
                        <?php else: ?>
                            <div class="list-group list-group-flush">
                                <?php foreach ($todos as $todo): ?>
                                    <div class="list-group-item <?= $todo['is_completed'] ? 'todo-completed' : '' ?>">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <div class="me-3">
                                                <h6 class="mb-1 <?= $todo['is_completed'] ? 'text-decoration-line-through text-muted' : '' ?>">
                                                    <?= htmlspecialchars($todo['title']) ?>
                                                </h6>
                                                <?php if (!empty($todo['description'])): ?>
                                                    <p class="mb-1 small text-muted"><?= htmlspecialchars($todo['description']) ?></p>
                                                <?php endif; ?>
                                                <small class="todo-date"><i class="bi bi-clock"></i> <?= date('M j, Y g:i A', strtotime($todo['created_at'])) ?></small>
                                            </div>
                                            <div class="todo-actions">
                                                <?php if (!$todo['is_completed']): ?>
                                                    <a href="complete.php?id=<?= $todo['id'] ?>" class="btn btn-sm btn-success" title="Mark Complete">
                                                        <i class="bi bi-check-lg"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <a href="edit.php?id=<?= $todo['id'] ?>" class="btn btn-sm btn-primary" title="Edit">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <a href="delete.php?id=<?= $todo['id'] ?>" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('Are you sure you want to delete this task?')">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Add hover effects
        document.querySelectorAll('.list-group-item').forEach(item => {
            item.addEventListener('mouseenter', () => {
                item.querySelector('.todo-actions').style.opacity = '1';
            });
            item.addEventListener('mouseleave', () => {
                item.querySelector('.todo-actions').style.opacity = '0.7';
            });
        });
    </script>
</body>
</html>