<?php
require_once 'config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $description = trim($_POST['description'] ?? '');

    if (empty($title)) {
        die("Title is required");
    }

    try {
       // In add.php, change the INSERT statement to:
$stmt = $pdo->prepare("INSERT INTO todos (title, description, is_completed) VALUES (?, ?, 0)");
$stmt->execute([$title, $description]);
        
        header('Location: index.php');
        exit;
    } catch (PDOException $e) {
        die("Error adding todo: " . $e->getMessage());
    }
} else {
    header('Location: index.php');
    exit;
}
?>