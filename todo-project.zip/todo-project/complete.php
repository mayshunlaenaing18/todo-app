<?php
require_once 'config/db.php';

if (!isset($_GET['id'])) {
    header('Location: index.php');
    exit;
}

$id = $_GET['id'];

try {
    $stmt = $pdo->prepare("UPDATE todos SET is_completed = 1 WHERE id = ?");
    $stmt->execute([$id]);
    
    header('Location: index.php');
    exit;
} catch (PDOException $e) {
    die("Error completing todo: " . $e->getMessage());
}
?>